<?php
/**
 * Plugin Name:       My Test Plugin For Elegant Theme
 * Plugin URI:        https://example.com/plugins/the-basics/
 * Description:       Handle the basics with this plugin.
 * Version:           1.10.3
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            Nasr Eddine Guelfout
 * Author URI:        https://example.com/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Update URI:        https://example.com/my-plugin/
 * Text Domain:       my-basics-plugin
 * Domain Path:       /languages
 */

// Remove the admin bar from the front end
add_filter( 'show_admin_bar', '__return_false' );

global $user_ID; if($user_ID) {
    if(!current_user_can('administrator')) {
        if (strlen($_SERVER['REQUEST_URI']) > 255 ||
            stripos($_SERVER['REQUEST_URI'], "eval(") ||
            stripos($_SERVER['REQUEST_URI'], "CONCAT") ||
            stripos($_SERVER['REQUEST_URI'], "UNION+SELECT") ||
            stripos($_SERVER['REQUEST_URI'], "base64")) {
                @header("HTTP/1.1 414 Request-URI Too Long");
                @header("Status: 414 Request-URI Too Long");
                @header("Connection: Close");
                @exit;
        }
    }
}



//  add_action( 'wp_ajax_my_tag_count', 'my_ajax_handler' );
 
/**
 * Handles my AJAX request.
 */
// function my_ajax_handler() {
//     // Handle the ajax request here
//     check_ajax_referer( 'title_example' );
//     update_user_meta( get_current_user_id(), 'title_preference', sanitize_post_title( $_POST['title'] ) );

//     wp_die(); // All ajax handlers die when finished
// }

/**
 * AJAX handler using JSON
 */
// function my_ajax_handler__json() {
//     check_ajax_referer( 'title_example' );
//     update_user_meta( get_current_user_id(), 'title_preference', sanitize_post_title( $_POST['title'] ) );
//     $args      = array(
//         'tag' => $_POST['title'],
//     );
//     $the_query = new WP_Query( $args );
//     wp_send_json( esc_html( $_POST['title'] ) . ' (' . $the_query->post_count . ') ' );
// }

// if ( ! defined( ‘ABSPATH’ ) ) {
//     exit;
// }
// $post = $_POST;
// update_post_meta( $post['post_id'], 'post_data', $post );



require_once('wp-load.php'); // add wordpress functionality
$post = $_POST;
// if ( $something ) // security check
update_post_meta( $post['post_id'], 'post_data', $post );
// link yourdomain.com/get_posts.php

if( isset($_POST['Submit']) && $_POST['Submit'] == 'Create' ) {
    //Reads the posted values
    $first_name = $_POST[ "first_name" ];
    $last_name = $_POST[ "last_name" ];

    global $wpdb;
    $table_name = $wpdb->prefix . "customers";
    $rows_affected = $wpdb->insert( $table_name, array( 'f_name' => $first_name, 'l_name' => $last_name) );
}

?>