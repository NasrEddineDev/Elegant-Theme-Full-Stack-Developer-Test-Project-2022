  <!-- Argon Scripts -->
  <!-- Core -->
  <script src="<?php echo e(asset('assets')); ?>/vendor/jquery/dist/jquery.min.js"></script>
  <script src="<?php echo e(asset('assets')); ?>/vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <script src="<?php echo e(asset('assets')); ?>/vendor/js-cookie/js.cookie.js"></script>
  <script src="<?php echo e(asset('assets')); ?>/vendor/jquery.scrollbar/jquery.scrollbar.min.js"></script>
  <script src="<?php echo e(asset('assets')); ?>/vendor/jquery-scroll-lock/dist/jquery-scrollLock.min.js"></script>
  <!-- Argon JS -->
  <script src="<?php echo e(asset('assets')); ?>/js/argon.js?v=1.2.0"></script><?php /**PATH /home/nasreddine/Downloads/test/Elegant-Theme-Full-Stack-Developer-Test-Project-2022/laravel-dashboard-webapp/resources/views/layouts/footers/scripts.blade.php ENDPATH**/ ?>